# Blood Bank Management System - web version (Python standard library + SQLite only).
# Run:  python server.py   then open http://localhost:8000
import sqlite3, json, os, re, hashlib, hmac, secrets
from http.cookies import SimpleCookie
from datetime import date
from urllib.parse import urlparse, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = "bloodbank.db"
G = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
GL = ",".join("'%s'" % g for g in G)

SCHEMA = f"""
CREATE TABLE IF NOT EXISTS donors(
  donor_id INTEGER PRIMARY KEY AUTOINCREMENT,            -- PRIMARY KEY
  name TEXT NOT NULL UNIQUE);                            -- UNIQUE constraint
CREATE TABLE IF NOT EXISTS hospitals(
  hospital_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS requests(
  request_id TEXT PRIMARY KEY,
  hospital_id INTEGER NOT NULL REFERENCES hospitals(hospital_id),   -- FOREIGN KEY
  blood_group TEXT NOT NULL CHECK(blood_group IN ({GL})),           -- CHECK constraint
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','PROCESSED','CANCELLED')));
CREATE TABLE IF NOT EXISTS blood_units(
  unit_id TEXT PRIMARY KEY,
  blood_group TEXT NOT NULL CHECK(blood_group IN ({GL})),
  donor_id INTEGER NOT NULL REFERENCES donors(donor_id),
  expiry TEXT NOT NULL CHECK(expiry GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  status TEXT NOT NULL DEFAULT 'AVAILABLE' CHECK(status IN ('AVAILABLE','ISSUED','EXPIRED')),
  request_id TEXT REFERENCES requests(request_id));
CREATE TABLE IF NOT EXISTS users(
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  salt TEXT NOT NULL,
  pw_hash TEXT NOT NULL);                                -- password is stored hashed, never as plain text
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  message TEXT NOT NULL);
"""

class ApiError(Exception):
    pass

SESS = {}  # session token -> user's name (cleared when the server restarts)

def hash_pw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 100000).hex()

def auth(con, path, b):
    user, pw = need(b, "username").lower(), str(b.get("password", ""))
    if path.endswith("signup"):
        name = need(b, "name")
        if len(user) < 3 or len(pw) < 6: raise ApiError("Username needs 3+ characters and password 6+")
        salt = secrets.token_bytes(16)
        try: con.execute("INSERT INTO users(username,full_name,salt,pw_hash) VALUES(?,?,?,?)", (user, name, salt.hex(), hash_pw(pw, salt)))
        except sqlite3.IntegrityError: raise ApiError("That username is already taken")
        return name
    r = con.execute("SELECT * FROM users WHERE username=?", (user,)).fetchone()
    if not r or not hmac.compare_digest(r["pw_hash"], hash_pw(pw, bytes.fromhex(r["salt"]))):
        raise ApiError("Invalid username or password")
    return r["full_name"]

def connect():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init():
    new = not os.path.exists(DB)
    con = connect(); con.executescript(SCHEMA)
    if new:  # seed with the data from the original console project
        add_unit(con, {"unit_id": "1001", "blood_group": "O-", "donor": "Nikshita", "expiry": "2027-04-28"})
        add_request(con, {"request_id": "101", "hospital": "XYZ hospital", "blood_group": "O-", "quantity": 2})
    con.commit(); con.close()

def q(con, sql, a=()):
    return [dict(r) for r in con.execute(sql, a)]

def log(con, msg):
    con.execute("INSERT INTO history(message) VALUES(?)", (msg,))

def name_id(con, table, col, name):
    con.execute(f"INSERT OR IGNORE INTO {table}(name) VALUES(?)", (name,))
    return con.execute(f"SELECT {col} FROM {table} WHERE name=?", (name,)).fetchone()[0]

def need(b, k):
    v = str(b.get(k, "")).strip()
    if not v: raise ApiError(f"{k.replace('_',' ')} is required")
    return v

def need_date(b, k):
    v = need(b, k)
    try: date.fromisoformat(v)
    except ValueError: raise ApiError("Use a real date in YYYY-MM-DD format")
    return v

def need_group(b):
    g = need(b, "blood_group").upper()
    if g not in G: raise ApiError("Invalid blood group")
    return g

# ---------- CREATE ----------
def add_unit(con, b):
    uid, g, exp = need(b, "unit_id"), need_group(b), need_date(b, "expiry")
    did = name_id(con, "donors", "donor_id", need(b, "donor"))
    con.execute("INSERT INTO blood_units(unit_id,blood_group,donor_id,expiry) VALUES(?,?,?,?)", (uid, g, did, exp))
    log(con, f"ADDED unit {uid} ({g})")

def add_request(con, b):
    rid, g = need(b, "request_id"), need_group(b)
    try: qty = int(b.get("quantity"))
    except (TypeError, ValueError): raise ApiError("Quantity must be a whole number")
    hid = name_id(con, "hospitals", "hospital_id", need(b, "hospital"))
    con.execute("INSERT INTO requests(request_id,hospital_id,blood_group,quantity) VALUES(?,?,?,?)", (rid, hid, g, qty))
    log(con, f"REGISTERED request {rid}")

# ---------- routing ----------
def handle(con, method, path, b, qs):
    p = path.strip("/").split("/")[1:]  # drop "api"
    if p == ["units"] and method == "GET":   # JOIN: units + donors
        return q(con, """SELECT u.unit_id, u.blood_group, d.name AS donor, u.expiry, u.status
                         FROM blood_units u JOIN donors d ON d.donor_id = u.donor_id ORDER BY u.unit_id""")
    if p == ["units"] and method == "POST":
        add_unit(con, b); return {"ok": "Blood unit added"}
    if len(p) == 2 and p[0] == "units" and method == "PUT":   # UPDATE
        u = con.execute("SELECT status FROM blood_units WHERE unit_id=?", (p[1],)).fetchone()
        if not u: raise ApiError("Unit not found")
        if u["status"] != "AVAILABLE": raise ApiError("Only AVAILABLE units can be updated")
        if b.get("donor"): con.execute("UPDATE blood_units SET donor_id=? WHERE unit_id=?", (name_id(con, "donors", "donor_id", b["donor"].strip()), p[1]))
        if b.get("expiry"): con.execute("UPDATE blood_units SET expiry=? WHERE unit_id=?", (need_date(b, "expiry"), p[1]))
        log(con, f"UPDATED unit {p[1]}"); return {"ok": "Unit updated"}
    if len(p) == 2 and p[0] == "units" and method == "DELETE":   # DELETE
        u = con.execute("SELECT status FROM blood_units WHERE unit_id=?", (p[1],)).fetchone()
        if not u: raise ApiError("Unit not found")
        if u["status"] == "ISSUED": raise ApiError("Issued units are part of the records and cannot be deleted")
        con.execute("DELETE FROM blood_units WHERE unit_id=?", (p[1],)); log(con, f"DELETED unit {p[1]}")
        return {"ok": "Unit deleted"}
    if p == ["requests"] and method == "GET":   # JOIN: requests + hospitals
        return q(con, """SELECT r.request_id, h.name AS hospital, r.blood_group, r.quantity, r.status
                         FROM requests r JOIN hospitals h ON h.hospital_id = r.hospital_id ORDER BY r.request_id""")
    if p == ["requests"] and method == "POST":
        add_request(con, b); return {"ok": "Request registered"}
    if len(p) == 3 and p[0] == "requests" and p[2] == "process":
        r = con.execute("SELECT * FROM requests WHERE request_id=?", (p[1],)).fetchone()
        if not r: raise ApiError("Request not found")
        if r["status"] != "PENDING": raise ApiError(f"Request is {r['status']}")
        today = need_date(b, "today")
        ids = [x[0] for x in con.execute(  # earliest expiry first (FEFO)
            """SELECT unit_id FROM blood_units WHERE blood_group=? AND status='AVAILABLE' AND expiry>=?
               ORDER BY expiry LIMIT ?""", (r["blood_group"], today, r["quantity"]))]
        if len(ids) < r["quantity"]: raise ApiError(f"Not enough stock: only {len(ids)} matching unit(s) available")
        for i in ids:
            con.execute("UPDATE blood_units SET status='ISSUED', request_id=? WHERE unit_id=?", (p[1], i))
            log(con, f"ISSUED unit {i} for request {p[1]}")
        con.execute("UPDATE requests SET status='PROCESSED' WHERE request_id=?", (p[1],))
        return {"ok": f"Issued {len(ids)} unit(s): {', '.join(ids)}. Exact group match only; compatibility must be verified by medical staff."}
    if len(p) == 3 and p[0] == "requests" and p[2] == "cancel":
        r = con.execute("SELECT status FROM requests WHERE request_id=?", (p[1],)).fetchone()
        if not r: raise ApiError("Request not found")
        if r["status"] != "PENDING": raise ApiError("Only PENDING requests can be cancelled")
        con.execute("UPDATE requests SET status='CANCELLED' WHERE request_id=?", (p[1],)); log(con, f"CANCELLED request {p[1]}")
        return {"ok": "Request cancelled"}
    if p == ["expiry"] and method == "GET":
        t = need_date({"t": qs.get("today", [""])[0]}, "t")
        return q(con, "SELECT unit_id, blood_group, expiry FROM blood_units WHERE status='AVAILABLE' AND expiry<=? ORDER BY expiry", (t,))
    if p == ["expiry"] and method == "POST":
        t = need_date(b, "today")
        for u in q(con, "SELECT unit_id FROM blood_units WHERE status='AVAILABLE' AND expiry<=?", (t,)):
            con.execute("UPDATE blood_units SET status='EXPIRED' WHERE unit_id=?", (u["unit_id"],)); log(con, f"EXPIRED unit {u['unit_id']}")
        return {"ok": "Expired units marked"}
    if p == ["shortage"]:
        n = {r["blood_group"]: r["n"] for r in con.execute("SELECT blood_group, COUNT(*) n FROM blood_units WHERE status='AVAILABLE' GROUP BY blood_group")}
        return [{"blood_group": g, "available": n.get(g, 0)} for g in G]
    if p == ["history"]:
        return q(con, "SELECT at, message FROM history ORDER BY id DESC")
    if p == ["analytics"]:
        return {"units": q(con, "SELECT status, COUNT(*) n FROM blood_units GROUP BY status"),
                "requests": q(con, "SELECT status, COUNT(*) n FROM requests GROUP BY status"),
                "hospitals": q(con, """SELECT h.name, COUNT(*) requests, SUM(r.quantity) units FROM requests r
                                       JOIN hospitals h ON h.hospital_id=r.hospital_id GROUP BY h.hospital_id ORDER BY units DESC""")}
    raise ApiError("Unknown endpoint")

class H(BaseHTTPRequestHandler):
    def token(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return c["session"].value if "session" in c else None

    def send(self, code, data, ctype="application/json", extra=None):
        body = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def run(self, method):
        u = urlparse(self.path)
        if method == "GET" and not u.path.startswith("/api"):
            return self.send(200, open("static/index.html", "rb").read(), "text/html; charset=utf-8")
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        con = connect()
        try:
            if u.path in ("/api/signup", "/api/login"):
                name = auth(con, u.path, body); con.commit()
                tok = secrets.token_hex(16); SESS[tok] = name
                return self.send(200, {"ok": "Welcome, " + name, "name": name},
                                 extra={"Set-Cookie": f"session={tok}; HttpOnly; Path=/; SameSite=Lax"})
            if u.path == "/api/logout":
                SESS.pop(self.token(), None)
                return self.send(200, {"ok": "Logged out"}, extra={"Set-Cookie": "session=; Path=/; Max-Age=0"})
            who = SESS.get(self.token())
            if not who: return self.send(401, {"error": "Please log in"})
            if u.path == "/api/me": return self.send(200, {"name": who})
            out = handle(con, method, u.path, body, parse_qs(u.query)); con.commit(); self.send(200, out)
        except ApiError as e:
            con.rollback(); self.send(400, {"error": str(e)})
        except sqlite3.IntegrityError as e:   # constraints fire here
            con.rollback(); m = str(e)
            self.send(400, {"error": "That ID/name already exists" if "UNIQUE" in m else "Rejected by a database constraint: " + m})
        finally: con.close()

    do_GET = lambda s: s.run("GET")
    do_POST = lambda s: s.run("POST")
    do_PUT = lambda s: s.run("PUT")
    do_DELETE = lambda s: s.run("DELETE")
    def log_message(self, *a): pass

if __name__ == "__main__":
    init()
    print("Blood Bank running at http://localhost:8000  (Ctrl+C to stop)")
    ThreadingHTTPServer(("", 8000), H).serve_forever()
