BLOOD BANK MANAGEMENT SYSTEM - WEB VERSION

RUN
1. Install Python 3.8+ (no extra packages needed).
2. In this folder run:  python server.py
3. Open http://localhost:8000 in your browser.
The database file bloodbank.db is created automatically on first run
(seeded with unit 1001 and request 101 from your console project).

FILES
server.py         Python server + SQLite database + API (CRUD, joins, constraints)
static/index.html The website (UI + Project Report tab)

WHITEBOARD TOPICS -> WHERE TO FIND THEM
Abstract, Introduction (UI/DB/Language), Objective, Project Info,
DFD/ER, Architecture, System requirements -> "Project Report" tab
Keys & Constraints -> SCHEMA in server.py (PRIMARY KEY, FOREIGN KEY, UNIQUE, CHECK, NOT NULL, DEFAULT)
Joins              -> /api/units and /api/requests, analytics in server.py
CRUD               -> add_unit/add_request (Create), GET routes (Read), PUT (Update), DELETE

NOTE: Educational project. Matches exact blood groups only; real transfusion
compatibility must be verified by qualified medical staff.
